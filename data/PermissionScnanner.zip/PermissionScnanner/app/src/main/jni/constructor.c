#include "constructor.h"
#include <android/log.h>
#define NULL 0
JNIEXPORT jobject JNICALL Java_ssl_ds_unipi_gr_permissionscnanner_JConstructor_generate (JNIEnv * je, jclass jc, jstring str){

    const char *_class = (*je)->GetStringUTFChars(je, str, 0);
    jclass cls = (*je)->FindClass(je, _class);
    jobject jobj = (*je)->AllocObject(je, cls);
    return jobj;
}
