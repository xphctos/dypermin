/*
package ssl.ds.unipi.gr.permissionscnanner;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.PrintWriter;
import java.io.StringWriter;
import android.content.Context;
import android.telephony.TelephonyManager;
import android.net.Uri;
import android.util.Log;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.lang.reflect.Method;
import android.bluetooth.BluetoothManager;

import java.lang.reflect.Constructor;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            Context context = App.getContext();
            Constructor<TelephonyManager> constructor = TelephonyManager.class.getDeclaredConstructor(Context.class);
            constructor.setAccessible(true);
            TelephonyManager tm = constructor.newInstance(context);
            try {
                tm = constructor.newInstance(context);

            } catch (InstantiationException | InvocationTargetException | IllegalAccessException e) {
                e.printStackTrace();
            }
            String id = tm.getDeviceId();
            System.out.println(id);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

    }
}

*/
        package ssl.ds.unipi.gr.permissionscnanner;
        import java.util.regex.Matcher;
        import java.util.regex.Pattern;
        import java.io.PrintWriter;
        import java.io.StringWriter;
        import android.util.Log;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import java.lang.reflect.Method;
        import java.lang.reflect.Constructor;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StringBuilder sb = new StringBuilder();
        try{
					/*static public android.accounts.AccountManager android.accounts.AccountManager get(android.content.Context)*/
            Method methodget = Class.forName("android.accounts.AccountManager").getDeclaredMethod("get");
            methodget.invoke(null);
            System.out.println("android.accounts.AccountManager static public android.accounts.AccountManager get(android.content.Context)" + " No Error");
        }
        catch (Exception e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            String error = sw.toString();
            String pattern = "android.permission.[A-Z_]+|No Carrier Privilege";
            Pattern r = Pattern.compile(pattern);
            Matcher m = r.matcher(error);
            if (m.find()) {
                sb.append("android.accounts.AccountManager static public android.accounts.AccountManager get(android.content.Context) " +  m.group(0));
                System.out.println("android.accounts.AccountManager static public android.accounts.AccountManager get(android.content.Context) " +  m.group(0));
            }else {
                e.printStackTrace();
                System.out.println("android.accounts.AccountManager static public android.accounts.AccountManager get(android.content.Context)" + " " + error);
            }
        }
    }
}