package ssl.ds.unipi.gr.permissionscnanner;

/**
 * Created by christoslyvas on 11/8/16.
 */
public class JConstructor {
    public static native Object generate(String className);
    static {
        System.loadLibrary("app");
    }

}
